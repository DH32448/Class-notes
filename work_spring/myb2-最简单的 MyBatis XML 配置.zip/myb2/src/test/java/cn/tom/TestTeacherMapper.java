package cn.tom;

import cn.tom.dao.TeacherMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestTeacherMapper {
// 从 IOC 容器 TeacherMapper 类型对象
    @Autowired
    TeacherMapper teacherMapper;

    @Test
    void findALl() {
        System.out.println(teacherMapper.findAll());
    }

}
