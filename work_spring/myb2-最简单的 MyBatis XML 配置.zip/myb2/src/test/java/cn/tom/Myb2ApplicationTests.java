package cn.tom;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Myb2ApplicationTests {

    @Test
    void contextLoads() {
    }

}
