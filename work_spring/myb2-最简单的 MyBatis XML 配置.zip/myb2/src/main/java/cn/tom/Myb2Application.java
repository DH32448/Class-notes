package cn.tom;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Myb2Application {

    public static void main(String[] args) {
        SpringApplication.run(Myb2Application.class, args);
    }

}
