package cn.tom.dao;

import org.apache.ibatis.annotations.Mapper;

import java.util.*;
@Mapper  //将这个 TeacherMapper 类型对象 put 到 IOC 容器
public interface TeacherMapper {
    public List<Map<String, Object>> findAll();
}
