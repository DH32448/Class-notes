package cn.tom;

import cn.tom.entity.Course;

import java.util.ArrayList;
import java.util.List;

public class DemoA {
    public static void main(String[] args) {
        List<Course> lst = doA();
    }

    private static List doA() {
        return new ArrayList();
    }
}
